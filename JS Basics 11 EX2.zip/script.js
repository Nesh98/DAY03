console.log('hello!')

const secondCat = document.querySelector('#second-cat-img');
const firstDiv = document.querySelector('#first-div');

firstDiv.appendChild(secondCat);